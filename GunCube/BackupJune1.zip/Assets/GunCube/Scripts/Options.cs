﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Options", menuName = "Options", order = 3)]
public class Options : ScriptableObject
{
    public float difficulty;
    public float recordDifficulty;

    public int score;
    public float highScore;

    public void CompleteRound(float diff)
    {
        difficulty = diff;
        if (diff > recordDifficulty) recordDifficulty = diff;
    }
    public void CheckHighScore(int score)
    {
        this.score = score;
        if (score > highScore) highScore = score;
    }
}
