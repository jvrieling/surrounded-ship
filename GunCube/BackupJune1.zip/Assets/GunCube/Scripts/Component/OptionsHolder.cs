﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OptionsHolder : MonoBehaviour
{
    public static Options options;

    public Options optionOnAwake;

    private void Awake()
    {
        if (optionOnAwake) options = optionOnAwake;
        else options = new Options();

        DontDestroyOnLoad(gameObject);
    }
}
